const persona = (nombre, edad) => console.log(`Hola, soy ${nombre} y tengo ${edad} años.`);
const numeros = [1,2,3,4,5];
const suma = (numeros) 